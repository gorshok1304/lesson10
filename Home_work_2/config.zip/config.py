STUDENTS_PATH = "students.json"
PROFESSIONS_PATH = "professions.json"